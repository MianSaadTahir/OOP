﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lab2;

//namespace lab2
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Student[] dataOFstudents = new Student[5];
//            for (int i = 0; i < 5; i++) 
//            {
//                dataOFstudents[i] = getStudentsDATA();
//            }
//            printStudentsDATA(dataOFstudents);
//            Console.Read();
//        }
//        static Student getStudentsDATA() 
//        {
//            Student s = new Student();

//            Console.WriteLine("Enter Name: ");
//            s.sname = Console.ReadLine();
            
//            Console.WriteLine("Enter Matric: ");
//            s.matricMarks=float.Parse(Console.ReadLine());
            
//            Console.WriteLine("Enter FSC: ");
//            s.fscMarks=float.Parse(Console.ReadLine());

//            Console.WriteLine("Enter ECAT: ");
//            s.ecatMarks=float.Parse(Console.ReadLine());

//            return s;

//        }
//        static void printStudentsDATA(Student[] dataOFstudents)
//        {
//            Console.WriteLine("Name\tMatric\tFSC\tECAT");
//            for (int i = 0;i <5;i++) 
//            {
//                Console.WriteLine(dataOFstudents[i].sname + '\t' + dataOFstudents[i].matricMarks + '\t' + dataOFstudents[i].fscMarks + '\t' + dataOFstudents[i].ecatMarks);
//            }

//        }
//    }
//}

namespace lab2
{
   class Program
    {
        static void Main(string[] args)
        {
            Student std1 = new Student();

            Console.WriteLine(std1.sname);
            //Console.WriteLine(std1.matricMarks);
            //Console.WriteLine(std1.fscMarks);
            //Console.WriteLine(std1.ecatMarks);
            //Console.WriteLine(std1.aggregate);

            Console.Read();
        }
    }
}
