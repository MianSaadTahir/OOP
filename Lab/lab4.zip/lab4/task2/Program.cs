﻿using System;
using task2.BL;

namespace task2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Customer customer = new Customer();
            customer.CustomerName = "Test";
            customer.CustomerAddress = "adas";
            customer.CustomerContact = "12313123";
            Console.WriteLine($"Customer name: {customer.CustomerName}");
            Console.WriteLine();

            Product product1 = new Product();
            product1.Name = "mango";
            product1.Price = 100;
            product1.Tax = product1.CalculateTax();
            Console.WriteLine($"Product1 name: {product1.Name}");
            Console.WriteLine($"Product1 price: {product1.Price}");
            Console.WriteLine($"Product1 after tax: {product1.Tax}");
            Console.WriteLine();


            customer.addProducts(product1);
            customer.products = customer.allProducts();

            for (int i = 0; i < customer.products.Count; i++)
            {
                Console.WriteLine($"Customer Products: ");
                Console.WriteLine($"Name: {customer.products[i].Name} \t Price: {customer.products[i].Tax}");
            }

        }
    }
}
