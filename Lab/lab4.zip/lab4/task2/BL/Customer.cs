﻿using System.Collections.Generic;

namespace task2.BL
{
    internal class Customer
    {
        public string CustomerName;
        public string CustomerAddress;
        public string CustomerContact;

        public List<Product> products = new List<Product>();
        public List<Product> allProducts()
        {
            return products;
        }
        public void addProducts(Product p)
        {
            products.Add(p);
        }
    }
}
