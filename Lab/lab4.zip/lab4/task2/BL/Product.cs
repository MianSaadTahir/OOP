﻿namespace task2.BL
{
    internal class Product
    {
        public string Name, Category;
        public double Price, Tax;

        public double CalculateTax()
        {
            double Tax = Price + (Price * 0.1);
            return Tax;
        }

    }
}
