﻿using System;
using task1.BL;

namespace task1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student s = new Student("saad", "2", 1028, 470, 280, true);
            double merit = s.CalulateMerit();
            bool scholarship = s.ScholarshipEligibility(merit);
            Console.WriteLine("merit: " + merit);
            Console.WriteLine("scholarship eligibility: " + scholarship);
        }
    }
}
