﻿namespace task1.BL
{
    internal class Student
    {
        private string name;
        private string rollNO;
        private double matric;
        private double fsc;
        private double ecat;
        private string hometown;
        private double merit;
        private bool hostellite;
        private bool scholarship;

        public Student(string name, string rollNO, double matric, double fsc, double ecat, bool hostellite)
        {
            this.name = name;
            this.rollNO = rollNO;
            this.matric = matric;
            this.fsc = fsc;
            this.ecat = ecat;
            this.hostellite = hostellite;
        }


        public double CalulateMerit()
        {
            double merit = ((matric * 0.1) + (ecat * 0.5) + (fsc * 0.4)) / 100;
            return merit;
        }
        public bool ScholarshipEligibility(double merit)
        {
            if (hostellite && merit > 80)
            {
                scholarship = true;
                return true;
            }
            return false;

        }
    }
}
