﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Self_Assessment_2.BL;

namespace Self_Assessment_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Calculator calculator = new Calculator();

            Console.Write("Enter Number 1: ");
            calculator.num1 = float.Parse(Console.ReadLine());
            Console.Write("Enter Number 2: ");
            calculator.num2 = float.Parse(Console.ReadLine());
            while (true)
            {
                Console.WriteLine();
                Console.Write("Enter Operation you want to perform (Addition / Subtraction / Multiplication / Division): ");
                string operation = Console.ReadLine();
                Console.WriteLine();

                if (operation == "Addition" || operation == "addition")
                {
                    float Answer = calculator.Answer(calculator.num1 + calculator.num2);
                    Console.WriteLine($"Answer: {Answer}");
                    break;
                }
                else if (operation == "Subtraction" || operation == "subtraction")
                {
                    float Answer = calculator.Answer(calculator.num1 - calculator.num2);
                    Console.WriteLine($"Answer: {Answer}");
                    break;
                }
                else if (operation == "Multiplication" || operation == "multiplication")
                {
                    float Answer = calculator.Answer(calculator.num1 * calculator.num2);
                    Console.WriteLine($"Answer: {Answer}");
                    break;
                }
                else if (operation == "Division" || operation == "division")
                {
                    float Answer = calculator.Answer(calculator.num1 / calculator.num2);
                    Console.WriteLine($"Answer: {Answer}");
                    break;
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("Wrong Option");
                }
                Console.Clear();
                Console.WriteLine($"Number 1: {calculator.num1}");
                Console.WriteLine($"Number 2: {calculator.num2}");
            }

            Console.ReadKey();  
        }
    }
}
