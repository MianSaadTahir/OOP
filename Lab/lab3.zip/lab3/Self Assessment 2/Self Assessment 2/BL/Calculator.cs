﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Self_Assessment_2.BL
{
    internal class Calculator
    {
        public float num1;
        public float num2;
        public Calculator()
        {

        }

        public float Answer(float a)
        {
            float answer;
            answer = a;
            return answer;
        }

    }
}
