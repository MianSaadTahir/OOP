﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Self_Assessment_1.BL;

namespace Self_Assessment_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Transaction transaction1 = new Transaction();

            Console.Write("Enter Transactrion 1 ID: ");
            transaction1.TransactionID = int.Parse(Console.ReadLine());
            Console.Write("Enter Product Name: ");
            transaction1.ProductName = Console.ReadLine();
            Console.Write("Enter Amount: ");
            transaction1.Amount = int.Parse(Console.ReadLine());
            Console.Write("Enter Date: ");
            transaction1.Date = Console.ReadLine();
            Console.Write("Enter Time: ");
            transaction1.Time = Console.ReadLine();
            Console.WriteLine();

            Transaction transaction2 = new Transaction(transaction1);

            Console.WriteLine($"Transaction 2 ID: {transaction2.TransactionID}");
            Console.WriteLine($"Transaction 2 Product: {transaction2.ProductName}");
            Console.WriteLine($"Transaction 2 Amount: {transaction2.Amount}");
            Console.WriteLine($"Transaction 2 Date: {transaction2.Date}");
            Console.WriteLine($"Transaction 2 Time: {transaction2.Time}");

            transaction2.ProductName = Console.ReadLine();

            Console.WriteLine($"Transaction 1 Product: {transaction1.ProductName}");
            Console.WriteLine($"Transaction 2 Product: {transaction2.ProductName}");

            Console.ReadKey();
        }
    }
}
