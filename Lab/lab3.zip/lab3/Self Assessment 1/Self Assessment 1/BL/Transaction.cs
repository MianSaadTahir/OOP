﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Self_Assessment_1.BL
{
    internal class Transaction
    {
        public int TransactionID;
        public string ProductName;
        public int Amount;
        public string Date;
        public string Time;

        public Transaction(Transaction t)
        {
            TransactionID = t.TransactionID;
            ProductName = t.ProductName;
            Amount = t.Amount;
            Date = t.Date;
            Time = t.Time;
        }

        public Transaction()
        {

        }
    }
}
