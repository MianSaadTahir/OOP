﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using challenge2.BL;

namespace challenge2
{
    internal class Program
    {
       
        static List<Product> products=new List<Product>();
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Clear();
                string option = menu();
                if (option == "1")
                {
                    add_product();
                    Console.ReadLine();
                }
                else if (option == "2")
                {
                    show_product();
                    Console.ReadLine();
                }
                else if (option == "3")
                {
                    show_worth();
                    Console.ReadLine();

                }
                else
                {
                    continue;

                }
            }
        }
        static string menu()
        {
            string option;
            Console.WriteLine("1. Add Product");
            Console.WriteLine("2. Show Product");
            Console.WriteLine("3. Total Store Worth");
            option = Console.ReadLine();
            return option;

        }
        static void add_product()
        {
            string id, name,category,brand,country;
            float price;
            Console.WriteLine("Enter ID");
            id = Console.ReadLine();

            Console.WriteLine("Enter product name");
            name = Console.ReadLine();

            Console.WriteLine("Enter product price");
            price = float.Parse(Console.ReadLine());

            Console.WriteLine("Enter category of brand");
            category= Console.ReadLine();

            Console.WriteLine("Enter product brand");
            brand = Console.ReadLine();

            Console.WriteLine("Enter product country");
            country = Console.ReadLine();


            Product s = new Product(id,name, price, category,brand,country);
            products.Add(s);
        }
        static void show_product()
        {
            for (int i = 0; i < products.Count; i++)
            {
                Console.WriteLine(products[i].show());

            }
        }
        static void  show_worth()
        {
            double sum = total_worth();
            Console.WriteLine("Total worth is {0}",sum);

        }
        static double total_worth()
        {
            double sum = 0;
            for (int i = 0;i < products.Count;i++) 
            {
                sum += products[i].price;
            }
            return sum;
        }
    }
}
