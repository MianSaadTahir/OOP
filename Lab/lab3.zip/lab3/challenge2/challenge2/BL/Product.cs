﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace challenge2.BL
{
    internal class Product
    {
        public Product()
        {

        }
        public Product(string id, string name, float price, string category, string brand_name, string country)
        { 
            this.id = id;
            this.name = name;   
            this.price = price;
            this.category = category;
            this.brand_name = brand_name;
            this.country = country;
        }
        public string id;
        public string name;
        public float price;
        public string category;
        public string brand_name;
        public string country;
        public string show()
        {
            string result= "Name" + name + "\nBrand" + brand_name + "\nPrice" + price;
            return result;
        }
    }
}
