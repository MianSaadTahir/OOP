﻿using System;
using System.Collections.Generic;

namespace lab3
{
    internal class Program
    {
        static List<Student> student = new List<Student>();
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Clear();
                string option = menu();
                if (option == "1")
                {
                    add_student();
                    Console.ReadLine();
                }
                else if (option == "2")
                {
                    show_student();
                    Console.ReadLine();
                }
                else if (option == "3")
                {
                    show_aggregate();
                    Console.ReadLine();

                }
                else if (option == "4")
                {
                    sorting();
                    top3();
                    Console.ReadLine();

                }
                else
                {
                    continue;

                }
            }
        }
        static string menu()
        {
            string option;
            Console.WriteLine("1. Add Student");
            Console.WriteLine("2. Show Student");
            Console.WriteLine("3. Calculate Aggregate");
            Console.WriteLine("4. Top Students");
            option = Console.ReadLine();
            return option;

        }
        static void add_student()
        {
            string name;
            int matric, fsc, ecat;
            float aggregate;
            Console.WriteLine("Enter your name");
            name = Console.ReadLine();

            Console.WriteLine("Enter your matric marks");
            matric = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter your fsc marks");
            fsc = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter your ecat marks");
            ecat = int.Parse(Console.ReadLine());

            aggregate = calculate_aggregate(matric, fsc, ecat);

            Student s = new Student(name, matric, fsc, ecat, aggregate);
            student.Add(s);
        }

        static float calculate_aggregate(int matric, int fsc, float ecat)
        {
            float result;
            result = ((matric * 10 / 1100) + (fsc * 40 / 1100) + (ecat * 50 / 400));
            return result;
        }
        static void show_student()
        {
            for (int i = 0; i < student.Count; i++)
            {
                Console.WriteLine("Student Name: {0}", student[i].name);
                Console.WriteLine("Student Matric : {0}", student[i].matric);
                Console.WriteLine("Student Fsc: {0}", student[i].fsc);
                Console.WriteLine("Student Ecat: {0}", student[i].ecat);

            }
        }
        static void show_aggregate()
        {
            for (int i = 0; i < student.Count; i++)
            {
                Console.WriteLine("Student Name: {0}", student[i].name);
                Console.WriteLine("Student Aggregate: {0}", student[i].aggregate);


            }
        }
        static void sorting()
        {
            Student temp = new Student();
            for (int i = 0; i < student.Count - 1; i++)
            {
                for (int j = 0; j < student.Count - 1; j++)

                {
                    if (student[j].aggregate < student[j + 1].aggregate)
                    {
                        temp = student[j];
                        student[j] = student[j + 1];
                    }
                }

            }
        }
        static void top3()
        {
            if (student.Count <= 3)
            {
                for (int i = 0; i < 3; i++)
                {
                    Console.WriteLine("Student Name: {0}", student[i].name);
                    Console.WriteLine("Student Aggregate: {0}", student[i].aggregate);

                }
            }
            else
            {
                for (int i = 0; i < student.Count; i++)
                {
                    Console.WriteLine("Student Name: {0}", student[i].name);
                    Console.WriteLine("Student Aggregate: {0}", student[i].aggregate);

                }

            }
        }
    }
}