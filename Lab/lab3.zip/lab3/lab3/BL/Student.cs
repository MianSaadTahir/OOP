﻿namespace lab3
{
    internal class Student
    {

        public Student(string name, int matric, int fsc, int ecat, float aggregate)
        {
            this.name = name;
            this.matric = matric;
            this.fsc = fsc;
            this.ecat = ecat;
            this.aggregate = aggregate;

        }

        public Student()
        {
        }

        public string name;
        public int matric, fsc, ecat;
        public float aggregate;
    }
}
