﻿using System;

namespace task4.BL
{
    internal class Book
    {
        public string title;
        public string author;
        public int publicationYear;
        public double price;
        public int quantityInStock;

        public Book(string title, string author, int publicationYear, double price, int quantityInStock)
        {
            this.title = title;
            this.author = author;
            this.publicationYear = publicationYear;
            this.price = price;
            this.quantityInStock = quantityInStock;
        }

        public string GetTitle()
        {
            return title;
        }

        public string GetAuthor()
        {
            return $"Author: {author}";
        }

        public string GetPublicationYear()
        {
            return $"Publication Year: {publicationYear}";
        }

        public string GetPrice()
        {
            return $"Price: {price:C2}";
        }

        public void SellCopies(int numberOfCopies)
        {

            if (quantityInStock >= numberOfCopies)
            {
                quantityInStock -= numberOfCopies;
                Console.WriteLine($"{numberOfCopies} copies sold. Remaining stock: {quantityInStock} copies.");

            }
            else
            {
                Console.WriteLine("Error: Not enough copies in stock.");

            }
        }

        public void Restock(int additionalCopies)
        {

            quantityInStock += additionalCopies;
            Console.WriteLine($"{additionalCopies} copies added to stock. New stock: {quantityInStock} copies.");

        }

        public string BookDetails()
        {
            Console.Clear();

            return $"Book Details:\n{GetTitle()}\n{GetAuthor()}\n{GetPublicationYear()}\n{GetPrice()}\nQuantity in Stock: {quantityInStock} copies";
            Console.ReadKey();

        }
    }
}
