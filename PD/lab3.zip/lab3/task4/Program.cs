﻿using System;
using System.Collections.Generic;
using task4.BL;

namespace task4
{
    internal class Program
    {
        static void Main()
        {
            List<Book> bookList = new List<Book>();

            do
            {
                Console.WriteLine("Menu Options:");
                Console.WriteLine("1. Add Book");
                Console.WriteLine("2. View All Books Information");
                Console.WriteLine("3. Get Author Details of a Specific Book");
                Console.WriteLine("4. Sell Copies of a Specific Book");
                Console.WriteLine("5. Restock a Specific Book");
                Console.WriteLine("6. See the Count of Books");
                Console.WriteLine("7. Exit");

                Console.Write("Enter your choice (1-7): ");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.Clear();

                        Console.Write("Enter book title: ");
                        string title = Console.ReadLine();
                        Console.Write("Enter book author: ");
                        string author = Console.ReadLine();
                        Console.Write("Enter publication year: ");
                        int publicationYear = int.Parse(Console.ReadLine());
                        Console.Write("Enter book price: ");
                        double price = Convert.ToDouble(Console.ReadLine());
                        Console.Write("Enter quantity in stock: ");
                        int quantityInStock = int.Parse(Console.ReadLine());

                        Book newBook = new Book(title, author, publicationYear, price, quantityInStock);
                        bookList.Add(newBook);

                        Console.WriteLine("Book added successfully!");
                        Console.ReadKey();
                        Console.Clear();

                        break;

                    case 2:
                        Console.Clear();

                        Console.WriteLine("All Books Information:");
                        foreach (var book in bookList)
                        {
                            Console.WriteLine(book.BookDetails());
                            Console.WriteLine();

                        }
                        Console.ReadKey();
                        Console.Clear();

                        break;

                    case 3:
                        Console.Clear();

                        Console.Write("Enter the title of the book to get author details: ");
                        string searchTitle = Console.ReadLine();
                        Book foundBook = bookList.Find(book => book.GetTitle().Equals(searchTitle, StringComparison.OrdinalIgnoreCase));

                        if (foundBook != null)
                        {
                            Console.WriteLine(foundBook.GetAuthor());
                        }
                        else
                        {
                            Console.WriteLine("Book not found.");
                        }
                        Console.ReadKey();

                        Console.Clear();

                        break;

                    case 4:
                        Console.Clear();

                        Console.Write("Enter the title of the book to sell copies: ");
                        string sellTitle = Console.ReadLine();
                        Book sellBook = bookList.Find(book => book.GetTitle().Equals(sellTitle, StringComparison.OrdinalIgnoreCase));

                        if (sellBook != null)
                        {
                            Console.Write("Enter the number of copies to sell: ");
                            int sellCopies = int.Parse(Console.ReadLine());
                            sellBook.SellCopies(sellCopies);
                        }
                        else
                        {
                            Console.WriteLine("Book not found.");
                        }
                        Console.ReadKey();

                        Console.Clear();

                        break;

                    case 5:
                        Console.Clear();

                        Console.Write("Enter the title of the book to restock: ");
                        string restockTitle = Console.ReadLine();
                        Book restockBook = bookList.Find(book => book.GetTitle().Equals(restockTitle, StringComparison.OrdinalIgnoreCase));

                        if (restockBook != null)
                        {
                            Console.Write("Enter the number of additional copies to restock: ");
                            int additionalCopies = int.Parse(Console.ReadLine());
                            restockBook.Restock(additionalCopies);
                        }
                        else
                        {
                            Console.WriteLine("Book not found.");
                        }
                        Console.ReadKey();

                        Console.Clear();
                        break;

                    case 6:
                        Console.Clear();

                        Console.WriteLine($"Number of books in stock: {bookList.Count}");
                        Console.ReadKey();

                        Console.Clear();
                        break;

                    case 7:
                        Console.WriteLine("Exiting the program.");
                        return;

                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 7.");
                        Console.ReadKey();

                        Console.Clear();
                        break;
                }

                Console.WriteLine();
            } while (true);
        }
    }
}