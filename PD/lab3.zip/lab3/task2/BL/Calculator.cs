﻿using System;

namespace task2.BL
{
    internal class Calculator
    {
        public double number1;
        public double number2;

        //default constructor
        public Calculator()
        {
            number1 = 10;
            number2 = 10;
        }

        // Parameterized constructor 
        public Calculator(double num1, double num2)
        {
            number1 = num1;
            number2 = num2;
        }

        // Method to change values for attributes 
        public void SetValues(double num1, double num2)
        {
            number1 = num1;
            number2 = num2;
        }

        // Method to add two numbers
        public double Add()
        {
            return number1 + number2;
        }

        // Method to subtract two numbers
        public double Subtract()
        {
            return number1 - number2;
        }

        // Method to multiply two numbers
        public double Multiply()
        {
            return number1 * number2;
        }

        // Method to divide two numbers 
        public double Divide()
        {
            if (number2 != 0)
            {
                return number1 / number2;
            }
            else //validation for not divisible by 0
            {
                Console.WriteLine("Error: Cannot divide by zero.");
                return double.NaN; // Not a Number
            }
        }

        // Method to calculate the modulo of two numbers
        public double Modulo()
        {
            if (number2 != 0)
            {
                return number1 % number2;
            }
            else
            {
                Console.WriteLine("Error: Cannot calculate modulo by zero.");
                return double.NaN; // Not a Number
            }
        }
        public double Sqrt(double num)
        {
            if (num >= 0)
            {
                return Math.Sqrt(num);
            }
            else
            {
                Console.WriteLine("Error: Cannot calculate square root of a negative number.");
                return double.NaN; // Not a Number
            }
        }

        public double Exp(double exponent)
        {
            return Math.Exp(exponent);
        }
        public double Log(double num)
        {
            if (num > 0)
            {
                return Math.Log(num);
            }
            else
            {
                Console.WriteLine("Error: Cannot calculate log of a non-positive number.");
                return double.NaN; // Not a Number
            }
        }

        public double Sin(double degrees)
        {
            return Math.Sin(degrees * Math.PI / 180);//math.pi used for pi value
        }

        public double Cos(double degrees)
        {
            return Math.Cos(degrees * Math.PI / 180);
        }

        public double Tan(double degrees)
        {
            if (Math.Abs(degrees % 180) != 90) // for undefined tangent at 90-degree multiples
            {
                return Math.Tan(degrees * Math.PI / 180);
            }
            else
            {
                Console.WriteLine("Error: Tangent is undefined at 90-degree multiples.");
                return double.NaN; // Not a Number
            }
        }
    }
}
