﻿using System;
using task2.BL;

namespace task2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Calculator myCalculator = null;

            int choice;
            do
            {
                Console.Clear();
                Console.WriteLine("Menu:");
                Console.WriteLine("1. Create a Single Object of Calculator");
                Console.WriteLine("2. Change Values of Attributes");
                Console.WriteLine("3. Add");
                Console.WriteLine("4. Subtract");
                Console.WriteLine("5. Multiply");
                Console.WriteLine("6. Divide");
                Console.WriteLine("7. Modulo");
                Console.WriteLine("8. Square Root");
                Console.WriteLine("9. Exponential Function");
                Console.WriteLine("10. Log");
                Console.WriteLine("11. Sine");
                Console.WriteLine("12. Cosine");
                Console.WriteLine("13. Tangent");
                Console.WriteLine("14. Exit");

                Console.Write("Enter your choice (1-14): ");
                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Do you want to enter values now? (y/n)");
                        string decision = Console.ReadLine();
                        if (decision == "y")
                        {
                            Console.Write("Enter the first number: ");
                            double num1 = Convert.ToDouble(Console.ReadLine());
                            Console.Write("Enter the second number: ");
                            double num2 = Convert.ToDouble(Console.ReadLine());
                            myCalculator = new Calculator(num1, num2);
                        }
                        else
                        {
                            myCalculator = new Calculator();

                        }
                        Console.ReadKey();
                        break;

                    case 2:
                        if (myCalculator != null)
                        {
                            Console.Write("Enter the new value for the first number: ");
                            double newNum1 = Convert.ToDouble(Console.ReadLine());
                            Console.Write("Enter the new value for the second number: ");
                            double newNum2 = Convert.ToDouble(Console.ReadLine());
                            myCalculator.SetValues(newNum1, newNum2);
                        }
                        else
                        {
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        }
                        Console.ReadKey();
                        break;

                    case 3:
                        if (myCalculator != null)
                            Console.WriteLine($"Result of addition: {myCalculator.Add()}");
                        else
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        Console.ReadKey();
                        break;

                    case 4:
                        if (myCalculator != null)
                            Console.WriteLine("Result of subtraction: " + myCalculator.Subtract());
                        else
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        Console.ReadKey();
                        break;

                    case 5:
                        if (myCalculator != null)
                            Console.WriteLine($"Result of multiplication: {myCalculator.Multiply()}");
                        else
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        Console.ReadKey();
                        break;

                    case 6:
                        if (myCalculator != null)
                            Console.WriteLine($"Result of division: {myCalculator.Divide()}");
                        else
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        Console.ReadKey();
                        break;

                    case 7:
                        if (myCalculator != null)
                            Console.WriteLine($"Result of modulo: {myCalculator.Modulo()}");
                        else
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        Console.ReadKey();
                        break;

                    case 8:
                        if (myCalculator != null)
                        {
                            Console.Write("Enter the number to calculate square root: ");
                            double sqrtNum = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine($"Square root: {myCalculator.Sqrt(sqrtNum)}");
                        }
                        else
                        {
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        }
                        Console.ReadKey();
                        break;

                    case 9:
                        if (myCalculator != null)
                        {
                            Console.Write("Enter the exponent for exponential function: ");
                            double expExponent = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine($"Exponential function result: {myCalculator.Exp(expExponent)}");
                        }
                        else
                        {
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        }
                        Console.ReadKey();
                        break;

                    case 10:
                        if (myCalculator != null)
                        {
                            Console.Write("Enter the number to calculate log: ");
                            double logNum = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine($"Natural logarithm: {myCalculator.Log(logNum)}");
                        }
                        else
                        {
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        }
                        Console.ReadKey();
                        break;

                    case 11:
                        if (myCalculator != null)
                        {
                            Console.Write("Enter the angle in degrees for sine: ");
                            double sinAngle = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine($"Sine value: {myCalculator.Sin(sinAngle)}");
                        }
                        else
                        {
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        }
                        Console.ReadKey();
                        break;

                    case 12:
                        if (myCalculator != null)
                        {
                            Console.Write("Enter the angle in degrees for cosine: ");
                            double cosAngle = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine($"Cosine value: {myCalculator.Cos(cosAngle)}");
                        }
                        else
                        {
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        }
                        Console.ReadKey();
                        break;

                    case 13:
                        if (myCalculator != null)
                        {
                            Console.Write("Enter the angle in degrees for tangent: ");
                            double tanAngle = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine($"Tangent value: {myCalculator.Tan(tanAngle)}");
                        }
                        else
                        {
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        }
                        Console.ReadKey();
                        break;

                    case 14:
                        Console.WriteLine("Exiting the program.");
                        break;

                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 14.");
                        Console.ReadKey();

                        break;
                }

                Console.WriteLine();
            } while (choice != 14);
        }
    }
}

