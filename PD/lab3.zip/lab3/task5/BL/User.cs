﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace task5.BL
{
    enum UserRole
    {
        Admin,
        Regular
    }

    // User class with sign-in, sign-up, and role-related behaviors
    internal class User
    {
        public string Username;
        public string Password;
        public UserRole Role;

        // Constructor for creating a new user
        public User(string username, string password, UserRole role)
        {
            Username = username;
            Password = password;
            Role = role;
        }

        // Sign-in method
        public bool SignIn(string enteredPassword)
        {
            return enteredPassword == Password;
        }

        // Sign-up method
        public static User SignUp(string username, string password, UserRole role)
        {

            if (Users.Any(user => user.Username == username))
            {
                Console.WriteLine("Error: User with the same username already exists.");
                return null;
            }

            User newUser = new User(username, password, role);
            Users.Add(newUser);
            Console.WriteLine("User created successfully.");
            return newUser;
        }

        // List to store users
        public static List<User> Users = new List<User>();
    }
}
