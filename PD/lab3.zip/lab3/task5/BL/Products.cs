﻿using System;
using System.Collections.Generic;

namespace task5.BL
{
    internal class Product
    {
        public int Id;
        public string Name;
        public double Price;

        // Constructor
        public Product(int id, string name, double price)
        {
            Id = id;
            Name = name;
            Price = price;
        }

        // Create a new product
        public static Product CreateProduct(int id, string name, double price)
        {
            Product newProduct = new Product(id, name, price);
            Products.Add(newProduct);
            Console.WriteLine("Product created successfully.");
            return newProduct;
        }

        // Read all products
        public static void ReadAllProducts()
        {
            foreach (var product in Products)
            {
                Console.WriteLine($"ID: {product.Id}, Name: {product.Name}, Price: {product.Price:C}");
            }
        }

        // Update product information
        public void UpdateProduct(string newName, double newPrice)
        {
            Name = newName;
            Price = newPrice;
            Console.WriteLine("Product updated successfully.");
        }

        // Delete a product
        public static void DeleteProduct(int productId)
        {
            Product productToDelete = Products.Find(product => product.Id == productId);
            if (productToDelete != null)
            {
                Products.Remove(productToDelete);
                Console.WriteLine("Product deleted successfully.");
            }
            else
            {
                Console.WriteLine("Error: Product not found.");
            }
        }

        // List to store products
        public static List<Product> Products = new List<Product>();
    }
}
