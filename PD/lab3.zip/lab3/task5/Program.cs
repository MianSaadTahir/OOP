﻿using System;
using task5.BL;

namespace task5
{
    internal class Program
    {
        static User currentUser;
        static Cart userCart = new Cart();
        static void Main()
        {
            // Create an admin user during program initialization
            User adminUser = new User("admin", "123", UserRole.Admin);

            // Main menu
            do
            {
                Console.WriteLine("Main Menu:");
                Console.WriteLine("1. Admin Sign In");
                Console.WriteLine("2. User Sign Up");
                Console.WriteLine("3. User Log In");
                Console.Write("Enter your choice (1-4): ");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.Clear();
                        Console.Write("Enter username: ");
                        string username = Console.ReadLine();
                        Console.Write("Enter password: ");
                        string password = Console.ReadLine();

                        if (adminUser.SignIn(password))
                        {
                            Console.WriteLine("Admin login Success!");
                            Console.ReadKey();


                            Console.Clear();
                            AdminMenu();
                        }
                        else
                        {
                            Console.WriteLine("Invalid credentials. Please try again.");
                        }
                        Console.ReadKey();
                        Console.Clear();

                        break;

                    case 2:
                        Console.Clear();

                        Console.Write("Enter username: ");
                        string signUpUsername = Console.ReadLine();
                        Console.Write("Enter password: ");
                        string signUpPassword = Console.ReadLine();

                        User.SignUp(signUpUsername, signUpPassword, UserRole.Regular);
                        Console.ReadKey();
                        Console.Clear();
                        break;

                    case 3:
                        Console.Clear();
                        UserSignIn();
                        Console.ReadKey();
                        Console.Clear();
                        break;

                    case 4:
                        Console.WriteLine("Exiting the program.");
                        return;

                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 3.");
                        Console.ReadKey();
                        Console.Clear();

                        break;
                }

                Console.WriteLine();
            } while (true);
        }
        static void UserSignIn()
        {
            Console.Write("Enter username: ");
            string username = Console.ReadLine();
            Console.Write("Enter password: ");
            string password = Console.ReadLine();

            currentUser = User.Users.Find(user => user.Username == username && user.SignIn(password));

            if (currentUser != null)
            {
                Console.WriteLine($"Welcome, {currentUser.Username}!");
                Console.ReadKey();
                Console.Clear();
                UserMenu();
            }
            else
            {
                Console.WriteLine("Invalid credentials. Please try again.");
            }
        }
        // Admin menu with CRUD operations for products
        static void AdminMenu()
        {
            do
            {
                Console.WriteLine("Admin Menu:");
                Console.WriteLine("1. Create Product");
                Console.WriteLine("2. Read All Products");
                Console.WriteLine("3. Update Product");
                Console.WriteLine("4. Delete Product");
                Console.WriteLine("5. Back to Main Menu");
                Console.Write("Enter your choice (1-5): ");
                int adminChoice = int.Parse(Console.ReadLine());

                switch (adminChoice)
                {
                    case 1:
                        Console.Clear();
                        Console.Write("Enter product ID: ");
                        int productId = int.Parse(Console.ReadLine());
                        Console.Write("Enter product name: ");
                        string productName = Console.ReadLine();
                        Console.Write("Enter product price: ");
                        double productPrice = Convert.ToDouble(Console.ReadLine());

                        Product.CreateProduct(productId, productName, productPrice);
                        Console.ReadKey();
                        Console.Clear();

                        break;

                    case 2:
                        Console.Clear();

                        Product.ReadAllProducts();
                        Console.ReadKey();
                        Console.Clear();
                        break;

                    case 3:
                        Console.Clear();

                        Console.Write("Enter the ID of the product to update: ");
                        int updateProductId = int.Parse(Console.ReadLine());

                        Product productToUpdate = Product.Products.Find(product => product.Id == updateProductId);
                        if (productToUpdate != null)
                        {
                            Console.Write("Enter new name: ");
                            string newName = Console.ReadLine();
                            Console.Write("Enter new price: ");
                            double newPrice = Convert.ToDouble(Console.ReadLine());

                            productToUpdate.UpdateProduct(newName, newPrice);
                        }
                        else
                        {
                            Console.WriteLine("Error: Product not found.");
                        }

                        Console.ReadKey();
                        Console.Clear();
                        break;

                    case 4:
                        Console.Clear();

                        Console.Write("Enter the ID of the product to delete: ");
                        int deleteProductId = int.Parse(Console.ReadLine());
                        Product.DeleteProduct(deleteProductId);
                        Console.ReadKey();
                        Console.Clear();
                        break;

                    case 5:
                        Console.WriteLine("Returning to the main menu.");

                        return;

                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 5.");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                }

                Console.WriteLine();
            } while (true);
        }
        static void UserMenu()
        {
            do
            {
                Console.WriteLine("User Menu:");
                Console.WriteLine("1. View Products");
                Console.WriteLine("2. Add Product to Cart");
                Console.WriteLine("3. View Cart");
                Console.WriteLine("4. Checkout");
                Console.WriteLine("5. Logout");
                Console.Write("Enter your choice (1-5): ");
                int userChoice = int.Parse(Console.ReadLine());

                switch (userChoice)
                {
                    case 1:
                        Console.Clear();

                        Product.ReadAllProducts();
                        Console.ReadKey();
                        Console.Clear();

                        break;

                    case 2:
                        Console.Clear();

                        Console.Write("Enter the ID of the product to add to cart: ");
                        int productId = int.Parse(Console.ReadLine());

                        Product selectedProduct = Product.Products.Find(product => product.Id == productId);
                        if (selectedProduct != null)
                        {
                            userCart.AddToCart(selectedProduct);
                        }
                        else
                        {
                            Console.WriteLine("Error: Product not found.");
                        }
                        Console.ReadKey();
                        Console.Clear();
                        break;

                    case 3:
                        Console.Clear();

                        userCart.ViewCart();
                        Console.ReadKey();
                        Console.Clear();
                        break;

                    case 4:
                        Console.Clear();

                        userCart.Checkout();
                        Console.ReadKey();
                        Console.Clear();
                        break;

                    case 5:
                        Console.WriteLine("Logging out.");
                        return;

                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 5.");
                        Console.ReadKey();
                        Console.Clear();

                        break;
                }

                Console.WriteLine();
            } while (true);
        }
    }
}