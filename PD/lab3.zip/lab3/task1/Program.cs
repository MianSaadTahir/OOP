﻿using System;
using task1.BL;

namespace task1
{

    internal class Program
    {
        static void Main()
        {
            Calculator myCalculator = null;

            int choice;
            do
            {
                Console.Clear();
                Console.WriteLine("1. Create a Single Object of Calculator");
                Console.WriteLine("2. Change Values of Attributes");
                Console.WriteLine("3. Add");
                Console.WriteLine("4. Subtract");
                Console.WriteLine("5. Multiply");
                Console.WriteLine("6. Divide");
                Console.WriteLine("7. Modulo");
                Console.WriteLine("8. Exit");

                Console.Write("Enter choice (1-8): ");
                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Do you want to enter values now? (y/n)");
                        string decision = Console.ReadLine();
                        if (decision == "y")
                        {
                            Console.Write("Enter the first number: ");
                            double num1 = Convert.ToDouble(Console.ReadLine());
                            Console.Write("Enter the second number: ");
                            double num2 = Convert.ToDouble(Console.ReadLine());
                            myCalculator = new Calculator(num1, num2);
                        }
                        else
                        {
                            myCalculator = new Calculator();

                        }
                        Console.ReadKey();
                        break;

                    case 2:
                        if (myCalculator != null)
                        {
                            Console.Write("Enter the new value for the first number: ");
                            double newNum1 = Convert.ToDouble(Console.ReadLine());
                            Console.Write("Enter the new value for the second number: ");
                            double newNum2 = Convert.ToDouble(Console.ReadLine());
                            myCalculator.SetValues(newNum1, newNum2);
                        }
                        else
                        {
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        }
                        Console.ReadKey();

                        break;

                    case 3:
                        if (myCalculator != null)
                            Console.WriteLine($"Result of addition: {myCalculator.Add()}");
                        else
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        Console.ReadKey();

                        break;

                    case 4:
                        if (myCalculator != null)
                            Console.WriteLine($"Result of subtraction: {myCalculator.Subtract()}");
                        else
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        Console.ReadKey();

                        break;

                    case 5:
                        if (myCalculator != null)
                            Console.WriteLine($"Result of multiplication: {myCalculator.Multiply()}");
                        else
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        Console.ReadKey();

                        break;

                    case 6:
                        if (myCalculator != null)
                            Console.WriteLine($"Result of division: {myCalculator.Divide()}");
                        else
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        Console.ReadKey();

                        break;

                    case 7:
                        if (myCalculator != null)
                            Console.WriteLine($"Result of modulo: {myCalculator.Modulo()}");
                        else
                            Console.WriteLine("Error: Calculator object not created. Please choose option 1 first.");
                        Console.ReadKey();

                        break;

                    case 8:
                        Console.WriteLine("Exiting the program.");


                        break;

                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 8.");
                        Console.ReadKey();

                        break;
                }

                Console.WriteLine();
            } while (choice != 8);
        }
    }
}