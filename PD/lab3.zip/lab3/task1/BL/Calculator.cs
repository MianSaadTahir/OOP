﻿using System;

namespace task1.BL
{
    internal class Calculator
    {
        public double number1;
        public double number2;

        //default constructor
        public Calculator()
        {
            number1 = 10;
            number2 = 10;
        }

        // Parameterized constructor 
        public Calculator(double num1, double num2)
        {
            number1 = num1;
            number2 = num2;
        }

        // Method to change values for attributes 
        public void SetValues(double num1, double num2)
        {
            number1 = num1;
            number2 = num2;
        }

        // Method to add two numbers
        public double Add()
        {
            return number1 + number2;
        }

        // Method to subtract two numbers
        public double Subtract()
        {
            return number1 - number2;
        }

        // Method to multiply two numbers
        public double Multiply()
        {
            return number1 * number2;
        }

        // Method to divide two numbers with error handling for division by zero
        public double Divide()
        {
            if (number2 != 0)
            {
                return number1 / number2;
            }
            else
            {
                Console.WriteLine("Error: Cannot divide by zero.");
                return double.NaN; // Not a Number
            }
        }

        // Method to calculate the modulo of two numbers
        public double Modulo()
        {
            if (number2 != 0)
            {
                return number1 % number2;
            }
            else
            {
                Console.WriteLine("Error: Cannot calculate modulo by zero.");
                return double.NaN; // Not a Number
            }
        }
    }
}
