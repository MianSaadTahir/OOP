// Task 1
// Class1.cs
/*
   using System;

namespace task1.BL
{
    internal class Calculator
    {
        public double number1;
        public double number2;

        //default constructor
        public Calculator()
        {
            number1 = 10;
            number2 = 10;
        }

        // Parameterized constructor 
        public Calculator(double num1, double num2)
        {
            number1 = num1;
            number2 = num2;
        }

        // Method to change values for attributes 
        public void SetValues(double num1, double num2)
        {
            number1 = num1;
            number2 = num2;
        }

        // Method to add two numbers
        public double Add()
        {
            return number1 + number2;
        }

        // Method to subtract two numbers
        public double Subtract()
        {
            return number1 - number2;
        }

        // Method to multiply two numbers
        public double Multiply()
        {
            return number1 * number2;
        }

        // Method to divide two numbers with error handling for division by zero
        public double Divide()
        {
            if (number2 != 0)
            {
                return number1 / number2;
            }
            else
            {
                Console.WriteLine("Error: Cannot divide by zero.");
                return double.NaN; // Not a Number
            }
        }

        // Method to calculate the modulo of two numbers
        public double Modulo()
        {
            if (number2 != 0)
            {
                return number1 % number2;
            }
            else
            {
                Console.WriteLine("Error: Cannot calculate modulo by zero.");
                return double.NaN; // Not a Number
            }
        }
    }
}

*/


// Task 2
// Class1.cs
/*
    using System;

namespace task2.BL
{
    internal class Calculator
    {
        public double number1;
        public double number2;

        //default constructor
        public Calculator()
        {
            number1 = 10;
            number2 = 10;
        }

        // Parameterized constructor 
        public Calculator(double num1, double num2)
        {
            number1 = num1;
            number2 = num2;
        }

        // Method to change values for attributes 
        public void SetValues(double num1, double num2)
        {
            number1 = num1;
            number2 = num2;
        }

        // Method to add two numbers
        public double Add()
        {
            return number1 + number2;
        }

        // Method to subtract two numbers
        public double Subtract()
        {
            return number1 - number2;
        }

        // Method to multiply two numbers
        public double Multiply()
        {
            return number1 * number2;
        }

        // Method to divide two numbers 
        public double Divide()
        {
            if (number2 != 0)
            {
                return number1 / number2;
            }
            else //validation for not divisible by 0
            {
                Console.WriteLine("Error: Cannot divide by zero.");
                return double.NaN; // Not a Number
            }
        }

        // Method to calculate the modulo of two numbers
        public double Modulo()
        {
            if (number2 != 0)
            {
                return number1 % number2;
            }
            else
            {
                Console.WriteLine("Error: Cannot calculate modulo by zero.");
                return double.NaN; // Not a Number
            }
        }
        public double Sqrt(double num)
        {
            if (num >= 0)
            {
                return Math.Sqrt(num);
            }
            else
            {
                Console.WriteLine("Error: Cannot calculate square root of a negative number.");
                return double.NaN; // Not a Number
            }
        }

        public double Exp(double exponent)
        {
            return Math.Exp(exponent);
        }
        public double Log(double num)
        {
            if (num > 0)
            {
                return Math.Log(num);
            }
            else
            {
                Console.WriteLine("Error: Cannot calculate log of a non-positive number.");
                return double.NaN; // Not a Number
            }
        }

        public double Sin(double degrees)
        {
            return Math.Sin(degrees * Math.PI / 180);//math.pi used for pi value
        }

        public double Cos(double degrees)
        {
            return Math.Cos(degrees * Math.PI / 180);
        }

        public double Tan(double degrees)
        {
            if (Math.Abs(degrees % 180) != 90) // for undefined tangent at 90-degree multiples
            {
                return Math.Tan(degrees * Math.PI / 180);
            }
            else
            {
                Console.WriteLine("Error: Tangent is undefined at 90-degree multiples.");
                return double.NaN; // Not a Number
            }
        }
    }
}

*/

//Task 3
//Class1.cs
/*
  using System;
using System.Collections.Generic;

namespace taskk3.BL
{
    internal class Shiritori
    {
        private List<string> words;
        public bool gameOver;

        public Shiritori()
        {
            words = new List<string>();
            gameOver = false;
        }

        public List<string> Words
        {
            get { return words; }
        }

        public bool GameOver
        {
            get { return gameOver; }
        }

        public string Play(string word)
        {
            if (gameOver)
            {
                return "Game over!";
            }

            if (string.IsNullOrEmpty(word))
            {
                return "Invalid word: Word cannot be empty.";
            }

            if (words.Contains(word))
            {
                return "Invalid word: Word has already been said.";
            }

            if (words.Count > 0 && word[0] != words[words.Count - 1][words[words.Count - 1].Length - 1])//get the last digit of last word in words array
            {
                return "Invalid word: First letter of the word must match the last letter of the previous word.";
            }

            words.Add(word);
            return string.Join(", ", words);//return list of words
        }
        public void Restart()
        {
            words.Clear();
            gameOver = false;
            Console.WriteLine("Game restarted.");
        }

    }
}
*/

//Task 4
//Class1.cs
/*
 using System;

namespace task4.BL
{
    internal class Book
    {
        public string title;
        public string author;
        public int publicationYear;
        public double price;
        public int quantityInStock;

        public Book(string title, string author, int publicationYear, double price, int quantityInStock)
        {
            this.title = title;
            this.author = author;
            this.publicationYear = publicationYear;
            this.price = price;
            this.quantityInStock = quantityInStock;
        }

        public string GetTitle()
        {
            return title;
        }

        public string GetAuthor()
        {
            return $"Author: {author}";
        }

        public string GetPublicationYear()
        {
            return $"Publication Year: {publicationYear}";
        }

        public string GetPrice()
        {
            return $"Price: {price:C2}";
        }

        public void SellCopies(int numberOfCopies)
        {

            if (quantityInStock >= numberOfCopies)
            {
                quantityInStock -= numberOfCopies;
                Console.WriteLine($"{numberOfCopies} copies sold. Remaining stock: {quantityInStock} copies.");

            }
            else
            {
                Console.WriteLine("Error: Not enough copies in stock.");

            }
        }

        public void Restock(int additionalCopies)
        {

            quantityInStock += additionalCopies;
            Console.WriteLine($"{additionalCopies} copies added to stock. New stock: {quantityInStock} copies.");

        }

        public string BookDetails()
        {
            Console.Clear();

            return $"Book Details:\n{GetTitle()}\n{GetAuthor()}\n{GetPublicationYear()}\n{GetPrice()}\nQuantity in Stock: {quantityInStock} copies";
            Console.ReadKey();

        }
    }
}
*/

//Task 5
//Class1.cs
/*using System;
using System.Collections.Generic;
using System.Linq;

namespace task5.BL
{
    enum UserRole
    {
        Admin,
        Regular
    }

    // User class with sign-in, sign-up, and role-related behaviors
    internal class User
    {
        public string Username;
        public string Password;
        public UserRole Role;

        // Constructor for creating a new user
        public User(string username, string password, UserRole role)
        {
            Username = username;
            Password = password;
            Role = role;
        }

        // Sign-in method
        public bool SignIn(string enteredPassword)
        {
            return enteredPassword == Password;
        }

        // Sign-up method
        public static User SignUp(string username, string password, UserRole role)
        {

            if (Users.Any(user => user.Username == username))
            {
                Console.WriteLine("Error: User with the same username already exists.");
                return null;
            }

            User newUser = new User(username, password, role);
            Users.Add(newUser);
            Console.WriteLine("User created successfully.");
            return newUser;
        }

        // List to store users
        public static List<User> Users = new List<User>();
    }
}
*/

//Class2.cs
/*using System;
using System.Collections.Generic;

namespace task5.BL
{
    internal class Product
    {
        public int Id;
        public string Name;
        public double Price;

        // Constructor
        public Product(int id, string name, double price)
        {
            Id = id;
            Name = name;
            Price = price;
        }

        // Create a new product
        public static Product CreateProduct(int id, string name, double price)
        {
            Product newProduct = new Product(id, name, price);
            Products.Add(newProduct);
            Console.WriteLine("Product created successfully.");
            return newProduct;
        }

        // Read all products
        public static void ReadAllProducts()
        {
            foreach (var product in Products)
            {
                Console.WriteLine($"ID: {product.Id}, Name: {product.Name}, Price: {product.Price:C}");
            }
        }

        // Update product information
        public void UpdateProduct(string newName, double newPrice)
        {
            Name = newName;
            Price = newPrice;
            Console.WriteLine("Product updated successfully.");
        }

        // Delete a product
        public static void DeleteProduct(int productId)
        {
            Product productToDelete = Products.Find(product => product.Id == productId);
            if (productToDelete != null)
            {
                Products.Remove(productToDelete);
                Console.WriteLine("Product deleted successfully.");
            }
            else
            {
                Console.WriteLine("Error: Product not found.");
            }
        }

        // List to store products
        public static List<Product> Products = new List<Product>();
    }
}
*/

//Class3.cs
/*using System;
using System.Collections.Generic;
using System.Linq;

namespace task5.BL
{
    internal class Cart
    {
        public List<Product> Items { get; }

        public Cart()
        {
            Items = new List<Product>();
        }

        public void AddToCart(Product product)
        {
            Items.Add(product);
            Console.WriteLine($"{product.Name} added to cart.");
        }

        public void ViewCart()
        {
            Console.WriteLine("Cart Contents:");
            foreach (var item in Items)
            {
                Console.WriteLine($"{item.Name}, Price: {item.Price:C}");
            }
        }

        public double CalculateTotal()
        {
            return Items.Sum(item => item.Price);
        }

        public void Checkout()
        {
            Console.WriteLine($"Total Amount: {CalculateTotal():C}");
            Console.WriteLine("Thank you for your purchase!");
            Items.Clear();
        }
    }
}
*/