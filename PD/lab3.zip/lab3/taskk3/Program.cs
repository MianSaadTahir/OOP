﻿using System;
using taskk3.BL;

namespace taskk3
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Shiritori game = new Shiritori();

            Console.WriteLine("Welcome to Shiritori!");

            while (!game.GameOver)
            {
                Console.WriteLine("Options:");
                Console.WriteLine("1. Play a word");
                Console.WriteLine("2. Restart the game");
                Console.WriteLine("3. Exit");

                Console.Write("Enter your choice (1-3): ");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.Write("Enter a word: ");
                        string word = Console.ReadLine();

                        string result = game.Play(word);
                        Console.WriteLine();
                        Console.WriteLine(result);
                        Console.WriteLine();


                        if (result.StartsWith("Game over"))
                        {
                            game.gameOver = true;
                        }
                        break;

                    case 2:
                        game.Restart();
                        Console.Clear();
                        break;

                    case 3:
                        Console.WriteLine("Exiting the game. Thanks for playing!");
                        game.gameOver = true;
                        break;

                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 3.");
                        break;
                }
            }
        }
    }
}
