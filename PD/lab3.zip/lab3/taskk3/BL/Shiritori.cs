﻿using System;
using System.Collections.Generic;

namespace taskk3.BL
{
    internal class Shiritori
    {
        private List<string> words;
        public bool gameOver;

        public Shiritori()
        {
            words = new List<string>();
            gameOver = false;
        }

        public List<string> Words
        {
            get { return words; }
        }

        public bool GameOver
        {
            get { return gameOver; }
        }

        public string Play(string word)
        {
            if (gameOver)
            {
                return "Game over!";
            }

            if (string.IsNullOrEmpty(word))
            {
                return "Invalid word: Word cannot be empty.";
            }

            if (words.Contains(word))
            {
                return "Invalid word: Word has already been said.";
            }

            if (words.Count > 0 && word[0] != words[words.Count - 1][words[words.Count - 1].Length - 1])//get the last digit of last word in words array
            {
                return "Invalid word: First letter of the word must match the last letter of the previous word.";
            }

            words.Add(word);
            return string.Join(", ", words);//return list of words
        }
        public void Restart()
        {
            words.Clear();
            gameOver = false;
            Console.WriteLine("Game restarted.");
        }

    }
}