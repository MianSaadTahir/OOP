﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace listTask
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Name: ");
            Console.ReadLine();
            Console.WriteLine("Enter Gender: ");
            Console.ReadLine();
            Console.WriteLine("Enter if putebaz: ");
            Console.ReadLine();


        }
    }
}
