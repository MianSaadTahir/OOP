﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using listTask;
namespace listTask
{
    internal class Putebaz
    {
        public string name;
        public string gender;
        public string role;
        public bool check;

        Putebaz(string name,string gender,string role) 
        { 
            this.name = name;
            this.gender = gender;
            check = checker(role);
        }
        public bool checker(string role)
        {
            if(role=="Putebaz")
            {
                role = "Putebaz";
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
