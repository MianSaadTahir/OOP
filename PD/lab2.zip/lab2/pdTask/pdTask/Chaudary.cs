﻿using System;

namespace pdTask
{
    internal class Chaudary
    {
        public string name;
        public int age;
        public string cast;
        public bool check;
        public bool checker(string c)
        {
            if (c == "ch")
            {
                cast = c;
                return true;
            }
            else
            {

                return false;
            }
        }
        public Chaudary(string n, int a, string c)
        {
            name = n;
            age = a;
            check = checker(c);
            if (check)
            {
                Console.WriteLine("You are Chaudary");
            }
            else
            {
                Console.WriteLine("You are not Chaudary");
            }
        }
    }
}
