﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using pdTask;

namespace pdTask
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name, cast;
            int age;
            Console.WriteLine("Enter Name");
            name=Console.ReadLine();

            Console.WriteLine("Enter Age");
            age=int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Cast");
            cast=Console.ReadLine();

            Chaudary chaudary = new Chaudary(name,age,cast); 


        }

    }
}
