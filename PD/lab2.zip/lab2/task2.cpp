// check frequency of an element
#include <iostream>
using namespace std;

int checkFrequentElement(int array[], int size);

main()
{
    int size;
    cout << "Enter size of array";
    cin >> size;
    int array[size];
    cout << "Enter elements of array" << endl;
    for (int i = 0; i < size; i++)
    {
        cin >> array[i];
    }
    int result = checkFrequentElement(array, size);
    cout << "Most frequent element: " << result;
}
int checkFrequentElement(int array[], int size)
{
    int maximumFrequency = 0;
    int highestFrequent = -1;
    for (int i = 0; i < size; i++)
    {
        int frequencyCount = 0;
        for (int j = 0; j < size; j++)
        {
            if (array[j] == array[i])
            {
                frequencyCount++;
            }
        }
        if (frequencyCount > maximumFrequency)
        {
            maximumFrequency = frequencyCount;
            highestFrequent = array[i];
        }
    }
    return highestFrequent;
}
