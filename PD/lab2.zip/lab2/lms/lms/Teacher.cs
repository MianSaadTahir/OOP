﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lms;

namespace lms
{
    internal class Teacher
    {
        public Teacher(string name, string id, string pass)
        {
            this.name= name;
            this.id= id;
            this.pass= pass;
        }
        public string name;
        public string id;
        public string pass;
    }
}
