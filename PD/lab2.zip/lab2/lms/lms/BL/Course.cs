﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LMS
{
    internal class Course
    {
        public Course(string name_, string id_)
        {
            name = name_;
            id = id_;

        }
        public string name;
        public string id;
    }
}
