﻿using System.Collections.Generic;

namespace task3.BL
{
    internal class Hand
    {
        private List<Card> cards;

        public Hand()
        {
            cards = new List<Card>();
        }

        public void Clear()
        {
            cards.Clear();
        }

        public void AddCard(Card card)
        {
            cards.Add(card);
        }

        public void RemoveCard(Card card)
        {
            cards.Remove(card);
        }

        public void RemoveCard(int position)
        {
            if (position >= 0 && position < cards.Count)
            {
                cards.RemoveAt(position);
            }
        }

        public int GetCardCount()
        {
            return cards.Count;
        }

        public Card GetCard(int position)
        {
            if (position >= 0 && position < cards.Count)
            {
                return cards[position];
            }
            else
            {
                return null;
            }
        }

        public override string ToString()
        {
            string handString = "";
            foreach (Card card in cards)
            {
                handString += card.ToString() + ", ";
            }
            return handString.TrimEnd(' ', ',');
        }
    }
}
