﻿namespace task3.BL
{
    internal class BlackjackHand : Hand
    {
        public int GetBlackjackValue()
        {
            int value = 0;
            bool ace = false;
            int cards = GetCardCount();

            for (int i = 0; i < cards; i++)
            {
                Card card = GetCard(i);
                int cardValue = card.GetValue();

                if (cardValue == 1)
                {
                    ace = true;
                    value += 11;
                }
                else if (cardValue >= 10)
                {
                    value += 10;
                }
                else
                {
                    value += cardValue;
                }
            }

            if (ace && value > 21)
            {
                value -= 10;
            }

            return value;
        }
    }
}
