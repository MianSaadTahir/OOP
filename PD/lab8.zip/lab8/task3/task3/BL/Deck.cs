﻿using System;
using System.Collections.Generic;

namespace task3.BL
{
    internal class Deck
    {
        private readonly List<Card> cards;
        private int currentCardIndex;

        public Deck()
        {
            cards = new List<Card>();
            currentCardIndex = 0;

            for (int suit = 1; suit <= 4; suit++)
            {
                for (int value = 1; value <= 13; value++)
                {
                    cards.Add(new Card(value, suit));
                }
            }
        }

        public void Shuffle()
        {
            Random random = new Random();
            for (int i = cards.Count - 1; i > 0; i--)
            {
                int randomIndex = random.Next(0, i + 1);
                Card temp = cards[i];
                cards[i] = cards[randomIndex];
                cards[randomIndex] = temp;
            }
            currentCardIndex = 0;
        }

        public int CardsLeft()
        {
            return cards.Count - currentCardIndex;
        }

        public Card DealCard()
        {
            if (currentCardIndex < cards.Count)
            {
                Card card = cards[currentCardIndex];
                currentCardIndex++;
                return card;
            }
            else
            {
                return null; // No more cards left in the deck
            }
        }
    }
}
