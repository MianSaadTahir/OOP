﻿using System;
using task3.BL;

namespace task3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Blackjack!");

            Deck deck = new Deck();
            deck.Shuffle();

            BlackjackHand playerHand = new BlackjackHand();
            BlackjackHand dealerHand = new BlackjackHand();

            // Initial deal
            playerHand.AddCard(deck.DealCard());
            playerHand.AddCard(deck.DealCard());

            dealerHand.AddCard(deck.DealCard());
            dealerHand.AddCard(deck.DealCard());

            Console.WriteLine("Your cards: " + playerHand.GetCard(0) + " and [Hidden]");
            Console.WriteLine("Dealer's cards: " + dealerHand.GetCard(0) + " and [Hidden]");

            // Player's turn
            while (true)
            {
                Console.Write("Do you want to Hit (H) or Stand (S)? ");
                string choice = Console.ReadLine();

                if (choice.ToLower() == "h")
                {
                    playerHand.AddCard(deck.DealCard());
                    Console.WriteLine("Your cards: " + playerHand);

                    if (playerHand.GetBlackjackValue() > 21)
                    {
                        Console.WriteLine("Busted! You lose.");
                        return;
                    }
                }
                else if (choice.ToLower() == "s")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter 'H' to Hit or 'S' to Stand.");
                }
            }

            // Dealer's turn
            Console.WriteLine("Dealer's cards: " + dealerHand);
            while (dealerHand.GetBlackjackValue() < 17)
            {
                dealerHand.AddCard(deck.DealCard());
                Console.WriteLine("Dealer hits: " + dealerHand.GetCard(dealerHand.GetCardCount() - 1));
            }

            if (dealerHand.GetBlackjackValue() > 21)
            {
                Console.WriteLine("Dealer busts! You win.");
            }
            else if (dealerHand.GetBlackjackValue() >= playerHand.GetBlackjackValue())
            {
                Console.WriteLine("Dealer wins.");
            }
            else
            {
                Console.WriteLine("You win!");
            }

            Console.WriteLine("Your hand: " + playerHand.GetBlackjackValue());
            Console.WriteLine("Dealer's hand: " + dealerHand.GetBlackjackValue());
        }
    }
}

