﻿namespace task1.BL
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
