﻿using System;

namespace task2.BL
{
    internal class Card
    {
        private readonly int value;
        private readonly int suit;

        public Card(int theValue, int theSuit)
        {
            value = theValue;
            suit = theSuit;
        }

        public string GetSuitAsString()
        {
            switch (suit)
            {
                case 1:
                    return "Clubs";
                case 2:
                    return "Diamonds";
                case 3:
                    return "Spades";
                case 4:
                    return "Hearts";
                default:
                    return "";
            }
        }

        public string GetValueAsString()
        {
            switch (value)
            {
                case 1:
                    return "Ace";
                case 11:
                    return "Jack";
                case 12:
                    return "Queen";
                case 13:
                    return "King";
                default:
                    return value.ToString();
            }
        }

        public override string ToString()
        {
            return GetValueAsString() + " of " + GetSuitAsString();
        }

        internal int GetValue()
        {
            throw new NotImplementedException();
        }
    }
}