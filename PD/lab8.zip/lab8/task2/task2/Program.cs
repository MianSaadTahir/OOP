﻿using System;
using task2.BL;

namespace task2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to HighLow!");

            int totalScore = 0;
            int gamesPlayed = 0;

            while (true)
            {
                Deck deck = new Deck();
                deck.Shuffle();

                int score = 0;

                Card currentCard = deck.DealCard();
                Console.WriteLine("Current card: " + currentCard);

                while (true)
                {
                    Console.Write("Predict higher (h) or lower (l): ");
                    string guess = Console.ReadLine();

                    if (guess.ToLower() == "h" || guess.ToLower() == "l")
                    {
                        Card nextCard = deck.DealCard();

                        if (nextCard == null)
                        {
                            Console.WriteLine("No more cards left. Game over.");
                            break;
                        }

                        Console.WriteLine("Next card: " + nextCard);

                        if ((guess.ToLower() == "h" && nextCard.GetValue() > currentCard.GetValue()) ||
                            (guess.ToLower() == "l" && nextCard.GetValue() < currentCard.GetValue()))
                        {
                            score++;
                            Console.WriteLine("Correct! Your score is now: " + score);
                            currentCard = nextCard;
                        }
                        else
                        {
                            Console.WriteLine("Incorrect! Game over. Your score: " + score);
                            break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. Please enter 'h' for higher or 'l' for lower.");
                    }
                }

                totalScore += score;
                gamesPlayed++;

                Console.Write("Do you want to play again? (yes/no): ");
                string playAgain = Console.ReadLine();

                if (playAgain.ToLower() != "yes")
                    break;
            }

            Console.WriteLine("Average score: " + (totalScore / (double)gamesPlayed));
        }
    }
}

