﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace task5.BL
{
    internal class Cart
    {
        public List<Product> Items { get; }

        public Cart()
        {
            Items = new List<Product>();
        }

        public void AddToCart(Product product)
        {
            Items.Add(product);
            Console.WriteLine($"{product.Name} added to cart.");
        }

        public void ViewCart()
        {
            Console.WriteLine("Cart Contents:");
            foreach (var item in Items)
            {
                Console.WriteLine($"{item.Name}, Price: {item.Price:C}");
            }
        }

        public double CalculateTotal()
        {
            return Items.Sum(item => item.Price);
        }

        public void Checkout()
        {
            Console.WriteLine($"Total Amount: {CalculateTotal():C}");
            Console.WriteLine("Thank you for your purchase!");
            Items.Clear();
        }
    }
}
