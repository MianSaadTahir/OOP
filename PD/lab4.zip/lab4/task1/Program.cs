﻿using System;
using System.Collections.Generic;
using task1.BL;

namespace task1
{
    class Program
    {
        static void Main(string[] args)
        {

            List<Ship> ships = new List<Ship>();
            Ship b = new Ship();
            int option;
            do
            {
                Console.Clear();
                option = menu();
                Console.Clear();
                if (option == 1)
                {

                    Ship s = b.takeinfo();
                    ships.Add(s);
                    Console.ReadKey();

                }
                if (option == 2)
                {
                    b.returnslocation(ships);
                    Console.ReadKey();

                }
                if (option == 3)
                {
                    string sn = b.returnshipnumber(ships);
                    Console.WriteLine("Ship's serial number is " + sn);
                    Console.ReadKey();

                }
                if (option == 4)
                {
                    b.updateship(ships);
                }
                if (option == 5)
                {
                    break;
                }

            }
            while (option < 6);
            Console.Read();
        }




        static int menu()
        {
            int option;
            Console.WriteLine("1.Add Ship");
            Console.WriteLine("2.View Ship Position");
            Console.WriteLine("3.View Ship serial number");
            Console.WriteLine("4.Change Ship Position");
            Console.WriteLine("5.Exit");
            option = int.Parse(Console.ReadLine());
            return option;
        }

    }
}
