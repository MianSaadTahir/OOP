﻿using System;
using System.Collections.Generic;

namespace task1.BL
{
    internal class Ship
    {
        public Ship()
        {

        }
        public Ship(string shipnumber)
        {
            this.shipnumber = shipnumber;
        }
        public Ship(string shipnumber, Angle shiplatitude, Angle shiplongitude)
        {
            this.shipnumber = shipnumber;
            this.shiplatitude = shiplatitude;
            this.shiplongitude = shiplongitude;
        }
        public Ship takeinfo()
        {
            string shipnumber;
            Angle a1 = new Angle();
            Angle a2 = new Angle();
            Console.WriteLine("Enter the ship number");
            shipnumber = Console.ReadLine();
            Console.WriteLine("Latitude ");
            Console.WriteLine("Enter Degrees :");
            a1.degrees = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Minutes :");
            a1.minutes = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Direction :");
            a1.direction = char.Parse(Console.ReadLine());
            Console.WriteLine("Longitude ");
            Console.WriteLine("Enter Degrees :");
            a2.degrees = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Minutes :");
            a2.minutes = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Direction :");
            a2.direction = char.Parse(Console.ReadLine());
            Ship s = new Ship(shipnumber, a1, a2);
            return s;
        }

        public void returnslocation(List<Ship> ships)
        {
            Console.WriteLine("Enter Ship Serial Number to find its position: ");
            string shipnumberofuser = Console.ReadLine();
            for (int idx = 0; idx < ships.Count; idx++)
            {
                if (shipnumberofuser == ships[idx].shipnumber)
                {
                    Console.WriteLine("Ship is at" + ships[idx].shiplatitude.degrees + "*" + ships[idx].shiplatitude.minutes + "'" + ships[idx].shiplatitude.direction + " and " + ships[idx].shiplongitude.degrees + "*" + ships[idx].shiplongitude.minutes + "'" + ships[idx].shiplongitude.direction);
                }
            }
        }

        public string returnshipnumber(List<Ship> ships)
        {
            Console.WriteLine("Ships's Latitude");
            Console.WriteLine("Enter Degrees : ");
            int degrees = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter minutes : ");
            float minutes = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter direction : ");
            char direction = char.Parse(Console.ReadLine());
            Console.WriteLine("Ships's Longitude");
            Console.WriteLine("Enter Degrees : ");
            int degrees1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter minutes : ");
            float minutes1 = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter direction : ");
            char direction1 = char.Parse(Console.ReadLine());
            for (int idx = 0; idx < ships.Count; idx++)
            {
                if (degrees == ships[idx].shiplatitude.degrees && minutes == ships[idx].shiplatitude.minutes && direction == ships[idx].shiplatitude.direction && degrees1 == ships[idx].shiplongitude.degrees && minutes1 == ships[idx].shiplongitude.minutes && direction1 == ships[idx].shiplongitude.direction)
                {
                    return ships[idx].shipnumber;
                }
            }
            return null;
        }

        public void updateship(List<Ship> ships)
        {
            Console.WriteLine("Enter Ship’s serial number whose position you want to change:");
            string shipnumber = Console.ReadLine();
            for (int idx = 0; idx < ships.Count; idx++)
            {
                if (shipnumber == ships[idx].shipnumber)
                {
                    Console.WriteLine("Ship Exists");
                    Console.WriteLine("Enter ship latitude : ");
                    Console.WriteLine("Enter degrees : ");
                    ships[idx].shiplatitude.degrees = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter minutes :  ");
                    ships[idx].shiplatitude.minutes = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter direction :  ");
                    ships[idx].shiplatitude.direction = char.Parse(Console.ReadLine());
                    Console.WriteLine("Enter ship longitude : ");
                    Console.WriteLine("Enter degrees : ");
                    ships[idx].shiplongitude.degrees = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter minutes :  ");
                    ships[idx].shiplongitude.minutes = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter direction :  ");
                    ships[idx].shiplongitude.direction = char.Parse(Console.ReadLine());
                }
            }

        }
        public string shipnumber;
        public Angle shiplatitude;
        public Angle shiplongitude;
    }
}
