﻿namespace task1.BL
{
    internal class Angle
    {
        public Angle()
        {

        }
        public Angle(int degrees, float minutes, char direction)
        {
            this.degrees = degrees;
            this.minutes = minutes;
            this.direction = direction;
        }


        public int degrees;
        public float minutes;
        public char direction;
    }
}
