﻿using System;

namespace task2.BL
{
    internal class Player
    {
        public string Name { get; private set; }
        public int Health { get; private set; }
        public int MaxHealth { get; private set; }
        public int Energy { get; private set; }
        public int MaxEnergy { get; private set; }
        public int Armor { get; private set; }
        public Stats SkillStatistics { get; private set; }

        public Player(string name, int health, int energy, int armor)
        {
            Name = name;
            MaxHealth = health;
            Health = Math.Min(health, MaxHealth);
            MaxEnergy = energy;
            Energy = Math.Min(energy, MaxEnergy);
            Armor = armor;
        }

        public void UpdateHealth(int value)
        {
            Health = Math.Max(0, Math.Min(value, MaxHealth));
        }

        public void UpdateEnergy(int value)
        {
            Energy = Math.Max(0, Math.Min(value, MaxEnergy));
        }

        public void UpdateArmor(int value)
        {
            Armor = value;
        }

        public void UpdateName(string newName)
        {
            Name = newName;
        }

        public void LearnSkill(Stats skillStats)
        {
            SkillStatistics = skillStats;
        }

        public string Attack(Player target)
        {
            // Calculate effective armor
            int effectiveArmor = Math.Max(0, target.Armor - (int)SkillStatistics.Penetration);

            // Check if enough energy to perform the attack
            if (SkillStatistics.Cost > Energy)
            {
                return $"{Name} attempted to use {SkillStatistics.Name}, but didn't have enough energy!";
            }

            // Subtract energy cost
            Energy -= SkillStatistics.Cost;

            // Calculate damage
            double calculatedDamage = SkillStatistics.Damage * ((100.0 - effectiveArmor) / 100.0);

            // Apply damage to the target
            target.UpdateHealth(target.Health - (int)calculatedDamage);

            // Apply healing to the caster
            Health += SkillStatistics.Heal;

            // Build the attack string
            string attackString = $"{Name} used {SkillStatistics.Name}, {SkillStatistics.Description}, against {target.Name}, doing {calculatedDamage:F2} damage!";
            if (SkillStatistics.Heal > 0)
            {
                attackString += $" {Name} healed for {SkillStatistics.Heal} health!";
            }

            // Check if the target player died
            if (target.Health <= 0)
            {
                attackString += $" {target.Name} died.";
            }
            else
            {
                attackString += $" {target.Name} is at {((double)target.Health / target.MaxHealth * 100):F2}% health.";
            }

            return attackString;
        }
    }
}
