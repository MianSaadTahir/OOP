﻿namespace task2.BL
{
    internal class Stats
    {
        public string Name { get; }
        public int Damage { get; }
        public double Penetration { get; }
        public int Heal { get; }
        public int Cost { get; }
        public string Description { get; }

        public Stats(string name, int damage, double penetration, int heal, int cost, string description)
        {
            Name = name;
            Damage = damage;
            Penetration = penetration;
            Heal = heal;
            Cost = cost;
            Description = description;
        }
    }

}
