﻿using System;
using System.Collections.Generic;
using task2.BL;

namespace task2
{
    class Program
    {
        static List<Player> players = new List<Player>();
        static List<Stats> skillStatistics = new List<Stats>();

        static void Main()
        {
            int choice;
            do
            {
                Console.Clear();
                Console.WriteLine("Magical Duel Game Menu");
                Console.WriteLine("1. Add Player");
                Console.WriteLine("2. Add Skill Statistics");
                Console.WriteLine("3. Display Player Info");
                Console.WriteLine("4. Learn a Skill");
                Console.WriteLine("5. Attack");
                Console.WriteLine("6. Exit");
                Console.Write("Enter your choice: ");

                if (int.TryParse(Console.ReadLine(), out choice))
                {
                    switch (choice)
                    {
                        case 1:
                            AddPlayer();
                            break;
                        case 2:
                            AddSkillStatistics();
                            break;
                        case 3:
                            DisplayPlayerInfo();
                            break;
                        case 4:
                            LearnSkill();
                            break;
                        case 5:
                            Attack();
                            break;
                        case 6:
                            Console.WriteLine("Exiting the program.");
                            break;
                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a number.");
                }

            } while (choice != 6);
        }

        static void AddPlayer()
        {
            Console.Write("Enter player name: ");
            string name = Console.ReadLine();
            Console.Write("Enter health: ");
            int health = int.Parse(Console.ReadLine());
            Console.Write("Enter max health: ");
            int maxHealth = int.Parse(Console.ReadLine());
            Console.Write("Enter energy: ");
            int energy = int.Parse(Console.ReadLine());
            Console.Write("Enter max energy: ");
            int maxEnergy = int.Parse(Console.ReadLine());
            Console.Write("Enter armor: ");
            int armor = int.Parse(Console.ReadLine());

            Player newPlayer = new Player(name, health, energy, armor);
            //newPlayer.MaxHealth = maxHealth;
            //newPlayer.MaxEnergy = maxEnergy;

            players.Add(newPlayer);

            Console.WriteLine($"Player {name} added successfully!");
            Console.ReadKey();
        }

        static void AddSkillStatistics()
        {
            Console.Write("Enter skill name: ");
            string name = Console.ReadLine();
            Console.Write("Enter damage: ");
            int damage = int.Parse(Console.ReadLine());
            Console.Write("Enter penetration: ");
            double penetration = double.Parse(Console.ReadLine());
            Console.Write("Enter heal: ");
            int heal = int.Parse(Console.ReadLine());
            Console.Write("Enter cost: ");
            int cost = int.Parse(Console.ReadLine());
            Console.Write("Enter description: ");
            string description = Console.ReadLine();

            Stats newSkill = new Stats(name, damage, penetration, heal, cost, description);
            skillStatistics.Add(newSkill);

            Console.WriteLine($"Skill {name} added successfully!");
            Console.ReadKey();

        }

        static void DisplayPlayerInfo()
        {
            Console.WriteLine("Player Information:");
            foreach (var player in players)
            {
                Console.WriteLine($"Name: {player.Name}, Health: {player.Health}/{player.MaxHealth}, Energy: {player.Energy}/{player.MaxEnergy}, Armor: {player.Armor}");
            }

        }

        static void LearnSkill()
        {
            Console.Write("Enter player name: ");
            string playerName = Console.ReadLine();
            Player player = players.Find(p => p.Name.Equals(playerName, StringComparison.OrdinalIgnoreCase));

            if (player != null)
            {
                Console.Write("Enter skill name: ");
                string skillName = Console.ReadLine();
                Stats skill = skillStatistics.Find(s => s.Name.Equals(skillName, StringComparison.OrdinalIgnoreCase));

                if (skill != null)
                {
                    player.LearnSkill(skill);
                    Console.WriteLine($"{playerName} learned {skillName} successfully!");
                }
                else
                {
                    Console.WriteLine($"Skill {skillName} not found.");
                }
            }
            else
            {
                Console.WriteLine($"Player {playerName} not found.");
            }
            Console.ReadKey();

        }

        static void Attack()
        {
            Console.WriteLine("Choose attacking player:");
            DisplayPlayerInfo();
            Console.Write("Enter attacking player name: ");
            string attackerName = Console.ReadLine();
            Player attacker = players.Find(p => p.Name.Equals(attackerName, StringComparison.OrdinalIgnoreCase));

            if (attacker != null)
            {
                Console.WriteLine("Choose target player:");
                DisplayPlayerInfo();
                Console.Write("Enter target player name: ");
                string targetName = Console.ReadLine();
                Player target = players.Find(p => p.Name.Equals(targetName, StringComparison.OrdinalIgnoreCase));

                if (target != null)
                {
                    string result = attacker.Attack(target);
                    Console.WriteLine(result);
                }
                else
                {
                    Console.WriteLine($"Target player {targetName} not found.");
                }
            }
            else
            {
                Console.WriteLine($"Attacking player {attackerName} not found.");
            }
            Console.ReadKey();

        }
    }
}
