﻿
//task 1

//    class Program


//    {
//        static void Main(string[] args)
//        {

//            List<Ship> ships = new List<Ship>();
//            Ship b = new Ship();
//            int option;
//            do
//            {
//                Console.Clear();
//                option = menu();
//                Console.Clear();
//                if (option == 1)
//                {

//                    Ship s = b.takeinfo();
//                    ships.Add(s);
//                    Console.ReadKey();

//                }
//                if (option == 2)
//                {
//                    b.returnslocation(ships);
//                    Console.ReadKey();

//                }
//                if (option == 3)
//                {
//                    string sn = b.returnshipnumber(ships);
//                    Console.WriteLine("Ship's serial number is " + sn);
//                    Console.ReadKey();

//                }
//                if (option == 4)
//                {
//                    b.updateship(ships);
//                }
//                if (option == 5)
//                {
//                    break;
//                }

//            }
//            while (option < 6);
//            Console.Read();
//        }




//        static int menu()
//        {
//            int option;
//            Console.WriteLine("1.Add Ship");
//            Console.WriteLine("2.View Ship Position");
//            Console.WriteLine("3.View Ship serial number");
//            Console.WriteLine("4.Change Ship Position");
//            Console.WriteLine("5.Exit");
//            option = int.Parse(Console.ReadLine());
//            return option;
//        }

//    }
//}

//      class Ship
//{
//    public Ship()
//    {

//    }
//    public Ship(string shipnumber)
//    {
//        this.shipnumber = shipnumber;
//    }
//    public Ship(string shipnumber, Angle shiplatitude, Angle shiplongitude)
//    {
//        this.shipnumber = shipnumber;
//        this.shiplatitude = shiplatitude;
//        this.shiplongitude = shiplongitude;
//    }
//    public Ship takeinfo()
//    {
//        string shipnumber;
//        Angle a1 = new Angle();
//        Angle a2 = new Angle();
//        Console.WriteLine("Enter the ship number");
//        shipnumber = Console.ReadLine();
//        Console.WriteLine("Latitude ");
//        Console.WriteLine("Enter Degrees :");
//        a1.degrees = int.Parse(Console.ReadLine());
//        Console.WriteLine("Enter Minutes :");
//        a1.minutes = float.Parse(Console.ReadLine());
//        Console.WriteLine("Enter Direction :");
//        a1.direction = char.Parse(Console.ReadLine());
//        Console.WriteLine("Longitude ");
//        Console.WriteLine("Enter Degrees :");
//        a2.degrees = int.Parse(Console.ReadLine());
//        Console.WriteLine("Enter Minutes :");
//        a2.minutes = float.Parse(Console.ReadLine());
//        Console.WriteLine("Enter Direction :");
//        a2.direction = char.Parse(Console.ReadLine());
//        Ship s = new Ship(shipnumber, a1, a2);
//        return s;
//    }

//    public void returnslocation(List<Ship> ships)
//    {
//        Console.WriteLine("Enter Ship Serial Number to find its position: ");
//        string shipnumberofuser = Console.ReadLine();
//        for (int idx = 0; idx < ships.Count; idx++)
//        {
//            if (shipnumberofuser == ships[idx].shipnumber)
//            {
//                Console.WriteLine("Ship is at" + ships[idx].shiplatitude.degrees + "*" + ships[idx].shiplatitude.minutes + "'" + ships[idx].shiplatitude.direction + " and " + ships[idx].shiplongitude.degrees + "*" + ships[idx].shiplongitude.minutes + "'" + ships[idx].shiplongitude.direction);
//            }
//        }
//    }

//    public string returnshipnumber(List<Ship> ships)
//    {
//        Console.WriteLine("Ships's Latitude");
//        Console.WriteLine("Enter Degrees : ");
//        int degrees = int.Parse(Console.ReadLine());
//        Console.WriteLine("Enter minutes : ");
//        float minutes = float.Parse(Console.ReadLine());
//        Console.WriteLine("Enter direction : ");
//        char direction = char.Parse(Console.ReadLine());
//        Console.WriteLine("Ships's Longitude");
//        Console.WriteLine("Enter Degrees : ");
//        int degrees1 = int.Parse(Console.ReadLine());
//        Console.WriteLine("Enter minutes : ");
//        float minutes1 = float.Parse(Console.ReadLine());
//        Console.WriteLine("Enter direction : ");
//        char direction1 = char.Parse(Console.ReadLine());
//        for (int idx = 0; idx < ships.Count; idx++)
//        {
//            if (degrees == ships[idx].shiplatitude.degrees && minutes == ships[idx].shiplatitude.minutes && direction == ships[idx].shiplatitude.direction && degrees1 == ships[idx].shiplongitude.degrees && minutes1 == ships[idx].shiplongitude.minutes && direction1 == ships[idx].shiplongitude.direction)
//            {
//                return ships[idx].shipnumber;
//            }
//        }
//        return null;
//    }

//    public void updateship(List<Ship> ships)
//    {
//        Console.WriteLine("Enter Ship’s serial number whose position you want to change:");
//        string shipnumber = Console.ReadLine();
//        for (int idx = 0; idx < ships.Count; idx++)
//        {
//            if (shipnumber == ships[idx].shipnumber)
//            {
//                Console.WriteLine("Ship Exists");
//                Console.WriteLine("Enter ship latitude : ");
//                Console.WriteLine("Enter degrees : ");
//                ships[idx].shiplatitude.degrees = int.Parse(Console.ReadLine());
//                Console.WriteLine("Enter minutes :  ");
//                ships[idx].shiplatitude.minutes = float.Parse(Console.ReadLine());
//                Console.WriteLine("Enter direction :  ");
//                ships[idx].shiplatitude.direction = char.Parse(Console.ReadLine());
//                Console.WriteLine("Enter ship longitude : ");
//                Console.WriteLine("Enter degrees : ");
//                ships[idx].shiplongitude.degrees = int.Parse(Console.ReadLine());
//                Console.WriteLine("Enter minutes :  ");
//                ships[idx].shiplongitude.minutes = float.Parse(Console.ReadLine());
//                Console.WriteLine("Enter direction :  ");
//                ships[idx].shiplongitude.direction = char.Parse(Console.ReadLine());
//            }
//        }

//    }
//    public string shipnumber;
//    public Angle shiplatitude;
//    public Angle shiplongitude;
//}

//class Angle

//{
//    public Angle()
//    {

//    }
//    public Angle(int degrees, float minutes, char direction)
//    {
//        this.degrees = degrees;
//        this.minutes = minutes;
//        this.direction = direction;
//    }


//        public int degrees;
//public float minutes;
//public char direction;
//    }









//task2

// class Program

//{
//    static List<Player> players = new List<Player>();
//    static List<Stats> skillStatistics = new List<Stats>();

//    static void Main()
//    {
//        int choice;
//        do
//        {
//            Console.Clear();
//            Console.WriteLine("Magical Duel Game Menu");
//            Console.WriteLine("1. Add Player");
//            Console.WriteLine("2. Add Skill Statistics");
//            Console.WriteLine("3. Display Player Info");
//            Console.WriteLine("4. Learn a Skill");
//            Console.WriteLine("5. Attack");
//            Console.WriteLine("6. Exit");
//            Console.Write("Enter your choice: ");

//            if (int.TryParse(Console.ReadLine(), out choice))
//            {
//                switch (choice)
//                {
//                    case 1:
//                        AddPlayer();
//                        break;
//                    case 2:
//                        AddSkillStatistics();
//                        break;
//                    case 3:
//                        DisplayPlayerInfo();
//                        break;
//                    case 4:
//                        LearnSkill();
//                        break;
//                    case 5:
//                        Attack();
//                        break;
//                    case 6:
//                        Console.WriteLine("Exiting the program.");
//                        break;
//                    default:
//                        Console.WriteLine("Invalid choice. Please try again.");
//                        break;
//                }
//            }
//            else
//            {
//                Console.WriteLine("Invalid input. Please enter a number.");
//            }

//        } while (choice != 6);
//    }

//    static void AddPlayer()
//    {
//        Console.Write("Enter player name: ");
//        string name = Console.ReadLine();
//        Console.Write("Enter health: ");
//        int health = int.Parse(Console.ReadLine());
//        Console.Write("Enter max health: ");
//        int maxHealth = int.Parse(Console.ReadLine());
//        Console.Write("Enter energy: ");
//        int energy = int.Parse(Console.ReadLine());
//        Console.Write("Enter max energy: ");
//        int maxEnergy = int.Parse(Console.ReadLine());
//        Console.Write("Enter armor: ");
//        int armor = int.Parse(Console.ReadLine());

//        Player newPlayer = new Player(name, health, energy, armor);
//        //newPlayer.MaxHealth = maxHealth;
//        //newPlayer.MaxEnergy = maxEnergy;

//        players.Add(newPlayer);

//        Console.WriteLine($"Player {name} added successfully!");
//        Console.ReadKey();
//    }

//    static void AddSkillStatistics()
//    {
//        Console.Write("Enter skill name: ");
//        string name = Console.ReadLine();
//        Console.Write("Enter damage: ");
//        int damage = int.Parse(Console.ReadLine());
//        Console.Write("Enter penetration: ");
//        double penetration = double.Parse(Console.ReadLine());
//        Console.Write("Enter heal: ");
//        int heal = int.Parse(Console.ReadLine());
//        Console.Write("Enter cost: ");
//        int cost = int.Parse(Console.ReadLine());
//        Console.Write("Enter description: ");
//        string description = Console.ReadLine();

//        Stats newSkill = new Stats(name, damage, penetration, heal, cost, description);
//        skillStatistics.Add(newSkill);

//        Console.WriteLine($"Skill {name} added successfully!");
//        Console.ReadKey();

//    }

//    static void DisplayPlayerInfo()
//    {
//        Console.WriteLine("Player Information:");
//        foreach (var player in players)
//        {
//            Console.WriteLine($"Name: {player.Name}, Health: {player.Health}/{player.MaxHealth}, Energy: {player.Energy}/{player.MaxEnergy}, Armor: {player.Armor}");
//        }

//    }

//    static void LearnSkill()
//    {
//        Console.Write("Enter player name: ");
//        string playerName = Console.ReadLine();
//        Player player = players.Find(p => p.Name.Equals(playerName, StringComparison.OrdinalIgnoreCase));

//        if (player != null)
//        {
//            Console.Write("Enter skill name: ");
//            string skillName = Console.ReadLine();
//            Stats skill = skillStatistics.Find(s => s.Name.Equals(skillName, StringComparison.OrdinalIgnoreCase));

//            if (skill != null)
//            {
//                player.LearnSkill(skill);
//                Console.WriteLine($"{playerName} learned {skillName} successfully!");
//            }
//            else
//            {
//                Console.WriteLine($"Skill {skillName} not found.");
//            }
//        }
//        else
//        {
//            Console.WriteLine($"Player {playerName} not found.");
//        }
//        Console.ReadKey();

//    }

//    static void Attack()
//    {
//        Console.WriteLine("Choose attacking player:");
//        DisplayPlayerInfo();
//        Console.Write("Enter attacking player name: ");
//        string attackerName = Console.ReadLine();
//        Player attacker = players.Find(p => p.Name.Equals(attackerName, StringComparison.OrdinalIgnoreCase));

//        if (attacker != null)
//        {
//            Console.WriteLine("Choose target player:");
//            DisplayPlayerInfo();
//            Console.Write("Enter target player name: ");
//            string targetName = Console.ReadLine();
//            Player target = players.Find(p => p.Name.Equals(targetName, StringComparison.OrdinalIgnoreCase));

//            if (target != null)
//            {
//                string result = attacker.Attack(target);
//                Console.WriteLine(result);
//            }
//            else
//            {
//                Console.WriteLine($"Target player {targetName} not found.");
//            }
//        }
//        else
//        {
//            Console.WriteLine($"Attacking player {attackerName} not found.");
//        }
//        Console.ReadKey();

//    }
//}

// class Player


//{
//        public string Name { get; private set; }
//public int Health { get; private set; }
//public int MaxHealth { get; private set; }
//public int Energy { get; private set; }
//public int MaxEnergy { get; private set; }
//public int Armor { get; private set; }
//public Stats SkillStatistics { get; private set; }

//public Player(string name, int health, int energy, int armor)
//{
//    Name = name;
//    MaxHealth = health;
//    Health = Math.Min(health, MaxHealth);
//    MaxEnergy = energy;
//    Energy = Math.Min(energy, MaxEnergy);
//    Armor = armor;
//}

//public void UpdateHealth(int value)
//{
//    Health = Math.Max(0, Math.Min(value, MaxHealth));
//}

//public void UpdateEnergy(int value)
//{
//    Energy = Math.Max(0, Math.Min(value, MaxEnergy));
//}

//public void UpdateArmor(int value)
//{
//    Armor = value;
//}

//public void UpdateName(string newName)
//{
//    Name = newName;
//}

//public void LearnSkill(Stats skillStats)
//{
//    SkillStatistics = skillStats;
//}

//public string Attack(Player target)
//{
//    // Calculate effective armor
//    int effectiveArmor = Math.Max(0, target.Armor - (int)SkillStatistics.Penetration);

//    // Check if enough energy to perform the attack
//    if (SkillStatistics.Cost > Energy)
//    {
//        return $"{Name} attempted to use {SkillStatistics.Name}, but didn't have enough energy!";
//    }

//    // Subtract energy cost
//    Energy -= SkillStatistics.Cost;

//    // Calculate damage
//    double calculatedDamage = SkillStatistics.Damage * ((100.0 - effectiveArmor) / 100.0);

//    // Apply damage to the target
//    target.UpdateHealth(target.Health - (int)calculatedDamage);

//    // Apply healing to the caster
//    Health += SkillStatistics.Heal;

//    // Build the attack string
//    string attackString = $"{Name} used {SkillStatistics.Name}, {SkillStatistics.Description}, against {target.Name}, doing {calculatedDamage:F2} damage!";
//    if (SkillStatistics.Heal > 0)
//    {
//        attackString += $" {Name} healed for {SkillStatistics.Heal} health!";
//    }

//    // Check if the target player died
//    if (target.Health <= 0)
//    {
//        attackString += $" {target.Name} died.";
//    }
//    else
//    {
//        attackString += $" {target.Name} is at {((double)target.Health / target.MaxHealth * 100):F2}% health.";
//    }

//    return attackString;
//}
//    }


//class Stats
//{
//    public string Name { get; }
//    public int Damage { get; }
//    public double Penetration { get; }
//    public int Heal { get; }
//    public int Cost { get; }
//    public string Description { get; }

//    public Stats(string name, int damage, double penetration, int heal, int cost, string description)
//    {
//        Name = name;
//        Damage = damage;
//        Penetration = penetration;
//        Heal = heal;
//        Cost = cost;
//        Description = description;
//    }
//}