﻿namespace Game1.Player
{
    internal class Player
    {
        public char[,] player = new char[3, 3];
        public int pX;
        public int pY;
        public Player()
        {
            this.player = new char[3, 3]  {
            {'|','i','|'},
            {';','-',';'},
            {';','_',';'},
        };
            pX = 3;
            pY = 10;
        }

    }
}